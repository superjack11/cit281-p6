class Shape {
    constructor(sides = [""]) {
        this.sides = sides;
    }

    perimeter = () => this.sides.length > 1 ? this.sides.reduce((total, side) => total + side) : "Not enough sides";
}

/*
console.log(new Shape([5, 10]).perimeter());  // 15
console.log(new Shape([1, 2, 3, 4, 5]).perimeter()); // 15
console.log(new Shape().perimeter()); // 0
*/

class Rectangle extends Shape {
    constructor(length = 0, width = 0) {
        super([length, width, length, width]);
        this.length = length;
        this.width = width;
    }

    area = () => this.length * this.width;
}

/*
console.log(new Rectangle(4, 4).perimeter());  // 16
console.log(new Rectangle(4, 4).area());  // 16
console.log(new Rectangle(5, 5).perimeter()); // 20
console.log(new Rectangle(5, 5).area()); // 25
console.log(new Rectangle().perimeter()); // 0
console.log(new Rectangle().area()); // 0
*/

class Triangle extends Shape {
    constructor(sideA = 0, sideB = 0, sideC = 0) {
        super([sideA, sideB, sideC]);
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
        this.peri = sideA + sideB + sideC;
    }

    area = () => Math.sqrt((this.peri/2)*((this.peri/2)-this.sideA)*((this.peri/2)-this.sideB)*((this.peri/2)-this.sideC));
}

/*
console.log(new Triangle(3, 4, 5).perimeter());  // 12
console.log(new Triangle(3, 4, 5).area());  // 6
console.log(new Triangle().perimeter()); // 0
console.log(new Triangle().area()); // 0
*/

const data = [ [3, 4], [5, 5], [3, 4, 5], [10], [] ];

Rect = new Rectangle(data[0][0], data[0][1]);
Squa = new Rectangle(data[1][0], data[1][1]);
Tri = new Triangle(data[2][0], data[2][1]);
shape1 = new Shape(data[3][0]);
shape2 = new Shape(data[4][0]);
console.log("Rectangle with sides " + data[0].toString() + " has a perimeter of " + Rect.perimeter() + " and an area of " + Rect.area());
console.log("Square with sides " + data[1].toString() + " has a perimeter of " + Squa.perimeter() + " and an area of " + Squa.area());
console.log("Triangle with sides " + data[2].toString() + " has a perimeter of " + Tri.perimeter() + " and an area of " + Tri.area());
console.log("Shape with " + shape1.sides.length + " side unsupported");
console.log("Shape with " + shape2.sides.length + " side unsupported");